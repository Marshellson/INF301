/*
 * @Author: ThearchyHelios
 * @Date: 2022-09-15 20:40:27
 * @LastEditTime: 2022-09-15 21:16:39
 * @LastEditors: ThearchyHelios
 * @Description:
 * @FilePath: /APP1/count_5_char_after.c
 */

#include <stdio.h>

// Count 5 char after the input file

int main(int argc, char *argv[])
{
    // read the input file
    FILE *input = fopen(argv[1], "r");
    if (input == NULL)
    {
        printf("Could not open %s.\n", argv[1]);
        return 1;
    }
    char c;
    while ((c = fgetc(input)) != EOF)
    {
        // check if backslash
        if (c == 92)
        {
            c = 118;
        }
        else if (c == 94)
        {
            c = 'x';
        }
        else if (c == 95)
        {
            c = 'y';
        }
        else if (c == 96)
        {
            c = 'z';
        }
        else if (c >= 'a' && c <= 'z')
        {
            c = c - 5;
            if (c > 'z')
            {
                c = c - 'z' + 'a' - 1;
            }
        }
        else if (c >= 'A' && c <= 'Z')
        {
            c = c - 5;
            if (c > 'Z')
            {
                c = c - 'Z' + 'A' - 1;
            }
        }
        else{
            c = c;
        }
        printf("%c", c);
    }
}
