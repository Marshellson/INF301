/*
 * @Author: ThearchyHelios
 * @Date: 2022-09-26 09:08:43
 * @LastEditTime: 2022-09-30 08:16:19
 * @LastEditors: ThearchyHelios
 * @Description: 
 * @FilePath: /APP1/Client c/crypteSeq.c
 */
