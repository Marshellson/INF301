/*
 * @Author: ThearchyHelios
 * @Date: 2022-09-26 09:29:28
 * @LastEditTime: 2022-09-26 09:30:38
 * @LastEditors: ThearchyHelios
 * @Description: 
 * @FilePath: /APP1/Client c/crypemove_essayer.c
 */

// cryptMove try encode

#include <stdio.h>

int main(){

}