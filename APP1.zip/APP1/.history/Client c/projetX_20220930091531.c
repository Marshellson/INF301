/*
 * @Author: ThearchyHelios
 * @Date: 2022-09-30 09:10:45
 * @LastEditTime: 2022-09-30 09:14:39
 * @LastEditors: ThearchyHelios
 * @Description: 
 * @FilePath: /APP1/Client c/projetX.c
 */

/*
 * @Author: ThearchyHelios
 * @Date: 2022-09-15 21:20:05
 * @LastEditTime: 2022-09-23 00:44:01
 * @LastEditors: ThearchyHelios
 * @Description:
 * @FilePath: /APP1/Client c/client-interactif.c
 */
#include "client.h"
#include <stdio.h>
#include <ctype.h>
#include <stdbool.h>
#include <string.h>

#define MAXMSG MAXREP

int main()
{
    /*	!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        !!! Éviter le plus possible de modifier ce fichier !!!
        !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

        Modifications autorisées :
            * login et mdp

        modifiez les variables ci-dessous: mettez vos identifiant et mot de passe
     */

    // char *login = "12100255";
    // char *mdp = "JIANG";
    char *serveur = "im2ag-appolab.u-ga.fr";
    int port = 9999;
    // En cas de problème de connexion, essayer sur le port 443 au lieu de 9999
    /* int port = 443; */

    /*	######################################
        #  NE PLUS RIEN MODIFIER CI-DESSOUS  #
        ######################################
     */

    char reponse[MAXREP];
    char message[MAXMSG];

    mode_debug(true);

    puts("Bienvenue dans le client interactif d'AppoLab");
    puts("Connection à AppoLab dans le client interactif d'AppoLab ...");

    // Connexion au serveur AppoLab
    connexion(serveur, port);

    strcpy(message, "login 12100255 JIANG");
    envoyer_recevoir(message, reponse);

    strcpy(message, "load projetX");
    envoyer_recevoir(message, reponse);

    strcpy(message, "help");
    envoyer_recevoir(message, reponse);

    strcpy(message, "depart");
    envoyer_recevoir(message, reponse);

    strcpy(message, "veni vidi vici");
    envoyer_recevoir(message, reponse);

    strcpy(message, "load crypteMove");
    envoyer_recevoir(message, reponse);

    return 0;
}
