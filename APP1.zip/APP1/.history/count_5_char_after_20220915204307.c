/*
 * @Author: ThearchyHelios
 * @Date: 2022-09-15 20:40:27
 * @LastEditTime: 2022-09-15 20:43:01
 * @LastEditors: ThearchyHelios
 * @Description: 
 * @FilePath: /APP1/count_5_char_after.c
 */

#include <stdio.h>

// Count 5 char after the input file

int main(int argc, char *argv[])
{
    char c;
    char c_5;
    printf("Please input a char: ");
    scanf("%c", &c);
    c_5 = c + 5;
    if (c_5 > 'z')
    {
        c_5 = c_5 - 'z' + 'a' - 1;
    }
    printf("The char after 5 is: %c
