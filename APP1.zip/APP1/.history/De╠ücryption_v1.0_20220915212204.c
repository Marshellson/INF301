/*
 * @Author: ThearchyHelios
 * @Date: 2022-09-15 21:21:47
 * @LastEditTime: 2022-09-15 21:21:48
 * @LastEditors: ThearchyHelios
 * @Description: 
 * @FilePath: /APP1/Décryption_v1.0.c
 */

#include <stdio.h>

#define BUFSIZE 512

int main()
{
    char buffer[BUFSIZE];

    while (fgets(buffer, BUFSIZE - 1, stdin))
    {

        // completer ici le code pour décrypter le message.


        printf(buffer);
    }

    return 0;
}