/*
 * @Author: ThearchyHelios
 * @Date: 2022-09-19 08:18:05
 * @LastEditTime: 2022-09-19 08:18:05
 * @LastEditors: ThearchyHelios
 * @Description: Pour encoder un message, on va utiliser la fonction suivante :
 * @FilePath: /APP1/CryptMove.c
 */


