/*
 * @Author: ThearchyHelios
 * @Date: 2022-09-19 08:18:05
 * @LastEditTime: 2022-09-19 08:56:02
 * @LastEditors: ThearchyHelios
 * @Description: Pour encoder un message
 * @FilePath: /APP1/CryptMove.c
 */

#include <stdio.h>

int main(int argc, char *argv[])
{
	int length_entrer 
}