/*
 * @Author: ThearchyHelios
 * @Date: 2022-09-15 20:40:27
 * @LastEditTime: 2022-09-15 20:40:28
 * @LastEditors: ThearchyHelios
 * @Description: 
 * @FilePath: /APP1/count_5_char_after.c
 */

#include <stdio.h>

// Count 5 char after the input file

int main(void)
{
    char input;
    char output;

    printf("Please input a char: \n");
    scanf("%c", &input);

    output = input + 5;
    if (output > 'z')
    {
        output = output - 'z' + 'a' - 1;
    }

    printf("\n%c\n", output);

    return 0;
}
