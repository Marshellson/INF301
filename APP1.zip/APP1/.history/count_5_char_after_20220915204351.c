/*
 * @Author: ThearchyHelios
 * @Date: 2022-09-15 20:40:27
 * @LastEditTime: 2022-09-15 20:43:01
 * @LastEditors: ThearchyHelios
 * @Description: 
 * @FilePath: /APP1/count_5_char_after.c
 */

#include <stdio.h>

// Count 5 char after the input file

int main(int argc, char *argv[])
{
    if (argc )
