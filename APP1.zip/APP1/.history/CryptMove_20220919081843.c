/*
 * @Author: ThearchyHelios
 * @Date: 2022-09-19 08:18:05
 * @LastEditTime: 2022-09-19 08:18:05
 * @LastEditors: ThearchyHelios
 * @Description: Pour encoder un message
 * @FilePath: /APP1/CryptMove.c
 */

#include <stdio.h>


int main(void)
{
    char lettreLue;
    char lettreSuivante3;
    char lettreSuivante5;
    char lettreSuivante7;
    char lettreSuivante11;
    char lettreSuivante13;
    char lettreSuivante17;
    char lettreSuivante19;
    char lettreSuivante23;
    char lettreSuivante29;
    char lettreSuivante31;
    char lettreSuivante37;
    char lettreSuivante41;
    char lettreSuivante43;
    char lettreSuivante47;
    char lettreSuivante53;
    char lettreSuivante59;
    char lettreSuivante61;
    char lettreSuivante67;
    char lettreSuivante71;
    char lettreSuivante73;
    char lettreSuivante79;
    char lettreSuivante83;
    char lettreSuivante89;
    char lettreSuivante97;
    char lettreSuivante101;
    char lettreSuivante103;
    char lettreSuivante107;
    char lettreSuivante109;
    char lettreSuivante113;
    char lettreSuivante127;
    char lettreSuivante131;
    char lettreSuivante137;
    char lettreSuivante139;
    char lettreSuivante149;
    char lettreSuivante151;
    char lettreSuivante157;
    char lettreSuivante163;
    char lettreSuivante167;
    char lettreSuivante173;
    char lettreSuivante179;
    char lettreSuivante181;
    char lettreSuivante191;
    char lettreSuivante193;
    char lettreSuivante197;
    char lettreSuivante199;
    char lettreSuivante211;
    char lettreSuivante223;
    char lettreSuivante227;
    char lettreSuivante229;
    char lettreSuivante233;
    char lettreSuivante239;
    char lettreSuivante241;
    char lettreSuivante251;
    char lettreSuivante257;
    char lettreSuivante263;
    char lettreSuivante269;
    char lettreSuivante271;
    char lettreSuivante277;
    char lettreSuivante281;
    char lettreSuivante283;
    char lettreSuivante293;